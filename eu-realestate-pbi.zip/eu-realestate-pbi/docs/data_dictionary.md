# Data Dictionary — EU_Real_Estate_Dataset.xlsx

| # | Column | Type | Description | Example |
|---|---|---|---|---|
| 1 | property_id | Text | Unique listing identifier | PROP-00001 |
| 2 | listing_date | Date | Date property listed | 2022-03-14 |
| 3 | listing_type | Text | Sale or Rental | Sale |
| 4 | property_type | Text | Apartment, Villa, Office, Retail, Townhouse, Mixed-Use, Warehouse | Apartment |
| 5 | country | Text | One of 10 EU countries | France |
| 6 | city | Text | One of 10 cities | Paris |
| 7 | address | Text | Street address | Rue de Rivoli 12 |
| 8 | latitude | Decimal | Geographic latitude | 48.8566 |
| 9 | longitude | Decimal | Geographic longitude | 2.3522 |
| 10 | square_meters | Integer | Property size in m² | 87 |
| 11 | bedrooms | Integer | Number of bedrooms (0 = studio/commercial) | 2 |
| 12 | bathrooms | Integer | Number of bathrooms | 1 |
| 13 | floor_number | Integer | Floor the unit is on | 5 |
| 14 | year_built | Integer | Year of construction | 1998 |
| 15 | energy_rating | Text | EU energy efficiency rating A–G | D |
| 16 | furnishing_status | Text | Furnished / Semi-Furnished / Unfurnished | Unfurnished |
| 17 | parking_spots | Integer | Number of parking spots included | 1 |
| 18 | elevator | Text | Yes / No | Yes |
| 19 | gym | Text | Yes / No | No |
| 20 | swimming_pool | Text | Yes / No | No |
| 21 | sale_price_eur | Decimal | Asking sale price in EUR (null for Rental) | 485000 |
| 22 | monthly_rent_eur | Decimal | Monthly rent in EUR (null for Sale) | 2400 |
| 23 | price_per_sqm | Decimal | sale_price_eur / square_meters | 5575 |
| 24 | days_on_market | Integer | Days since listing date | 142 |
| 25 | last_sold_price_eur | Decimal | Previous transaction price (may be null) | 310000 |

## Null Handling
- `sale_price_eur` is null for Rental listings — always filter `listing_type = "Sale"` before averaging
- `monthly_rent_eur` is null for Sale listings — filter `listing_type = "Rental"` before averaging  
- `last_sold_price_eur` has nulls where no prior transaction exists — use `NOT ISBLANK()` in DAX
- `furnishing_status` has some nulls — safe to ignore in group-by measures
